<template>
  <div>
    <div class="warning custom-block">
      <p class="custom-block-title">Important</p>
      <p>
        <strong>Vuesax</strong> desde la <strong>v4.0+</strong> ya no depende de ninguna libreria de iconos 👏, ahora los iconos son un <code>slot</code> para una mejor personalizacion e independencia, en caso de no agregar ningun icono se usa un <strong>svg</strong> por defecto.
      </p>
    </div>
    <div class="tip custom-block">
      <p class="custom-block-title">Tip</p>
      <p>
        Estos documentos y los ejemplos usan los iconos <a target="_blank" href="https://boxicons.com/">Boxicons</a>, no dependemos de esta libreria de iconos pero la recomendamos para el uso de vuesax 4.0+.
        <br>
        <br>
        Sin problema puede usar los iconos o svg que usted desee o librerias como <strong>material-icons</strong> y <strong>font-awesome</strong> o cualquier otra
      </p>
    </div>
  </div>
</template>
<script>
export default {

}
</script>
