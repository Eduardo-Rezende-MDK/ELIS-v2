<template>
  <div>
    <p>
      Use the <code>color</code> property to change the base color of the component and some of the child components, to better understand the handling of colors and themes you can see it<router-link to="/docs/theme/">here</router-link>
      <br>
      <br>
    </p>
    <p>
      Allowed values ​​are:
    </p>
    <ul>
      <li><code>primary</code></li>
      <li><code>success</code></li>
      <li><code>danger</code></li>
      <li><code>warning</code></li>
      <li><code>dark</code></li>
      <li><code>RGB</code></li>
      <li><code>HEX</code></li>
    </ul>
  </div>
</template>
<style scoped lang="stylus">
  a
    text-decoration underline
</style>
