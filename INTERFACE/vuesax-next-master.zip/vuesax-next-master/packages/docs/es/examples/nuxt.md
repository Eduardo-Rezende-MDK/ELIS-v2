# Vuesax with Nuxt

## Init Project

## Install Vuesax
