<template>
  <div class="center">
    <vs-button
      to="/"
      flat
      >
      To - vue-router
    </vs-button>
    <vs-button
      href="http://vuesax.com/"
      success
      flat
    >
      Href - Replace Url
    </vs-button>
    <vs-button
      href="http://vuesax.com/"
      blank
      danger
      flat
    >
      Href - Open External (blank)
    </vs-button>
  </div>
</template>
