<template>
  <div class="center">
    <vs-button
      icon
      color="facebook"
    >
      <i class='bx bxl-facebook-square'></i>
    </vs-button>

    <vs-button
      icon
      color="twitter"
    >
      <i class='bx bxl-twitter'></i>
    </vs-button>

    <vs-button
      icon
      color="youtube"
    >
      <i class='bx bxl-youtube'></i>
    </vs-button>

    <vs-button
      icon
      color="linkedin"
    >
      <i class='bx bxl-linkedin'></i>
    </vs-button>

    <vs-button
      icon
      color="whatsapp"
    >
      <i class='bx bxl-whatsapp'></i>
    </vs-button>

    <vs-button
      icon
      color="twitch"
    >
      <i class='bx bxl-twitch'></i>
    </vs-button>

    <vs-button
      icon
      color="medium"
    >
      <i class='bx bxl-medium'></i>
    </vs-button>

    <vs-button
      icon
      color="skype"
    >
      <i class='bx bxl-skype'></i>
    </vs-button>

    <vs-button
      icon
      color="slack"
    >
      <i class='bx bxl-slack-old'></i>
    </vs-button>

    <vs-button
      icon
      color="messenger"
    >
      <i class='bx bxl-messenger'></i>
    </vs-button>

    <vs-button
      icon
      color="tumblr"
    >
      <i class='bx bxl-tumblr'></i>
    </vs-button>

    <vs-button
      icon
      color="dribbble"
    >
      <i class='bx bxl-dribbble'></i>
    </vs-button>

    <vs-button
      icon
      color="google-plu
    s">
      <i class='bx bxl-google-plus'></i>
    </vs-button>

    <vs-button
      icon
      color="vimeo"
    >
      <i class='bx bxl-vimeo'></i>
    </vs-button>

    <vs-button
      icon
      color="pinterest"
    >
      <i class='bx bxl-pinterest'></i>
    </vs-button>

    <vs-button
      icon
      color="spotify"
    >
      <i class='bx bxl-spotify'></i>
    </vs-button>

    <vs-button
      icon
      color="discord"
    >
      <i class='bx bxl-discord'></i>
    </vs-button>

    <vs-button
      icon
      color="amazon"
    >
      <i class='bx bxl-amazon'></i>
    </vs-button>

    <vs-button
      icon
      color="reddit"
    >
      <i class='bx bxl-reddit'></i>
    </vs-button>
  </div>
</template>
<style lang="stylus" scoped>
.center
  flex-wrap wrap
  padding 20px
  max-width 400px
  margin auto
</style>

