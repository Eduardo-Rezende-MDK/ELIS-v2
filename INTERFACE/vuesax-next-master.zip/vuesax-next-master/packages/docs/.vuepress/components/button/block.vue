<template>
  <div class="center">
    <vs-button
      block
    >
      <i class='bx bxs-paint-roll' ></i> Edit Theme
    </vs-button>
  </div>
</template>
<script>
export default {
  data:() => ({
    active: 0
  })
}
</script>
<style lang="stylus" scoped>
.center
  max-width 400px
  margin auto
</style>

