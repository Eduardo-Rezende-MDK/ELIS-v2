<template>
  <div class="center">
    <vs-button
      circle
      icon
      floating
    >
      <i class='bx bx-plus' ></i>
    </vs-button>

    <vs-button
      color="whatsapp"
      circle
      icon
      floating
    >
      <i class='bx bxl-whatsapp' ></i>
    </vs-button>

    <vs-button
      color="#ff3e4e"
      circle
      icon
      floating
    >
      <i class='bx bx-up-arrow-alt' ></i>
    </vs-button>

    <vs-button
      circle
      icon
      disabled
      floating
    >
      <i class='bx bxs-chat' ></i>
    </vs-button>
  </div>
</template>

