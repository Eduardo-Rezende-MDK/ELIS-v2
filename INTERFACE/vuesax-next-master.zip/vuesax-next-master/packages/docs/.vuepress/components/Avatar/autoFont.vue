<template>
  <div class="center con-avatars">
    <vs-avatar>
      <template #text>
        L
      </template>
    </vs-avatar>
    <vs-avatar>
      <template #text>
        Joel
      </template>
    </vs-avatar>
    <vs-avatar>
      <template #text>
        Fanny
      </template>
    </vs-avatar>
    <vs-avatar>
      <template #text>
        Sally Willis
      </template>
    </vs-avatar>
    <vs-avatar>
      <template #text>
        Dakota Roche Brown
      </template>
    </vs-avatar>
    <vs-avatar>
      <template #text>
        Garret Reynolds Enarson Hoffman
      </template>
    </vs-avatar>
  </div>
</template>
<script>
export default {

}
</script>
<style scoped lang="stylus">
  .con-avatars
    .vs-avatar-content
      margin 10px
</style>
