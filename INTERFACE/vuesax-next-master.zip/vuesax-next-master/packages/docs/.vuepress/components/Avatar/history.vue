<template>
  <div class="center con-avatars">
    <vs-avatar history>
      <img src="/avatars/avatar-5.png" alt="">
    </vs-avatar>

    <vs-avatar history primary>
      <img src="/avatars/avatar-5.png" alt="">
    </vs-avatar>

    <vs-avatar history success>
      <img src="/avatars/avatar-5.png" alt="">
    </vs-avatar>

    <vs-avatar history history-gradient>
      <img src="/avatars/avatar-5.png" alt="">
    </vs-avatar>
  </div>
</template>
<script>
export default {

}
</script>
<style scoped lang="stylus">
  .con-avatars
    .vs-avatar-content
      margin 10px
</style>
