<template>
  <div class="center con-avatars">
    <vs-avatar>
      <i class='bx bx-user'></i>
    </vs-avatar>
    <vs-avatar>
      <i class='bx bxs-camera' ></i>
    </vs-avatar>
    <vs-avatar>
      <i class='bx bx-world' ></i>
    </vs-avatar>
    <vs-avatar>
      <i class='bx bx-support' ></i>
    </vs-avatar>
    <vs-avatar>
      <i class='bx bx-trophy' ></i>
    </vs-avatar>
    <vs-avatar>
      <i class='bx bx-map' ></i>
    </vs-avatar>
  </div>
</template>
<script>
export default {

}
</script>
<style scoped lang="stylus">
  .con-avatars
    .vs-avatar-content
      margin 10px
</style>
