import { Alert } from '../index'

class Test extends Alert {
    progress: string = '60'
    color: string = 's'
}