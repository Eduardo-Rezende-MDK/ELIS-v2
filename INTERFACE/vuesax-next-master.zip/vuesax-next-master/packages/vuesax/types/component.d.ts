import Vue from 'vue/types/index'

/** ElementUI component common definition */
export declare class VuesaxUIComponent extends Vue {
  /** Install component into Vue */
  static install(vue: typeof Vue): void
}